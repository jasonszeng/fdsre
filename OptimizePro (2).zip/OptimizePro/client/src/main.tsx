import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// 确保root元素存在
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Failed to find the root element");
}

createRoot(rootElement).render(<App />);