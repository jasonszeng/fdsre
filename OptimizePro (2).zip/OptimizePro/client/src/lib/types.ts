export interface Message {
  id: number;
  content: string;
  authorId: number;
  channel: string;
  isPrivate: boolean;
  recipientId?: number;
  imageUrl?: string;
  fileUrl?: string;  
  fileName?: string;
  createdAt: Date;
}

export interface User {
  id: number;
  username: string;
  status: string;
  lastActive: Date;
}

export type WebSocketMessage = {
  type: 'join' | 'message' | 'userJoined' | 'newMessage';
  username?: string;
  data?: any;
  message?: Message;
}
