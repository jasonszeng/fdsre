import { useEffect, useRef, useCallback } from 'react';
import type { WebSocketMessage } from '@/lib/types';

export function useWebSocket(onMessage: (msg: WebSocketMessage) => void) {
  const wsRef = useRef<WebSocket | null>(null);

  const connect = useCallback(() => {
    // 获取正确的WebSocket协议
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      console.log('WebSocket连接已建立');
    };

    wsRef.current.onmessage = (event) => {
      const message = JSON.parse(event.data);
      onMessage(message);
    };

    wsRef.current.onerror = (error) => {
      console.error('WebSocket错误:', error);
    };

    wsRef.current.onclose = () => {
      console.log('WebSocket连接已关闭,1秒后尝试重连');
      // 1秒后尝试重连
      setTimeout(connect, 1000);
    };
  }, [onMessage]);

  useEffect(() => {
    connect();
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket未连接,消息未发送:', message);
    }
  }, []);

  return { sendMessage };
}