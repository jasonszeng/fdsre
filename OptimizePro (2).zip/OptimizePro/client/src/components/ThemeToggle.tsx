import { Moon, Sun, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme.tsx";
import { motion } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative z-50"
    >
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="relative h-10 w-10 rounded-full bg-background/80 backdrop-blur-sm hover:bg-accent transition-all duration-300"
          >
            <motion.div
              initial={false}
              animate={{
                scale: theme === "light" ? 1 : 0,
                rotate: theme === "light" ? 0 : -90,
              }}
              transition={{ duration: 0.2 }}
              className="absolute"
            >
              <Sun className="h-5 w-5 text-yellow-500" />
            </motion.div>
            <motion.div
              initial={false}
              animate={{
                scale: theme === "dark" ? 1 : 0,
                rotate: theme === "dark" ? 0 : 90,
              }}
              transition={{ duration: 0.2 }}
              className="absolute"
            >
              <Moon className="h-5 w-5 text-blue-500" />
            </motion.div>
            <motion.div
              initial={false}
              animate={{
                scale: theme === "system" ? 1 : 0,
                rotate: theme === "system" ? 0 : 90,
              }}
              transition={{ duration: 0.2 }}
              className="absolute"
            >
              <Monitor className="h-5 w-5 text-gray-500" />
            </motion.div>
            <span className="sr-only">Toggle theme</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-32">
          <DropdownMenuItem 
            onClick={() => setTheme("light")}
            className="cursor-pointer"
          >
            <Sun className="mr-2 h-4 w-4 text-yellow-500" />
            <span>Light</span>
          </DropdownMenuItem>
          <DropdownMenuItem 
            onClick={() => setTheme("dark")}
            className="cursor-pointer"
          >
            <Moon className="mr-2 h-4 w-4 text-blue-500" />
            <span>Dark</span>
          </DropdownMenuItem>
          <DropdownMenuItem 
            onClick={() => setTheme("system")}
            className="cursor-pointer"
          >
            <Monitor className="mr-2 h-4 w-4 text-gray-500" />
            <span>System</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </motion.div>
  );
}