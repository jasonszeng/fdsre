import { useRef, useEffect } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { motion, AnimatePresence } from 'framer-motion';
import type { Message, User } from '@/lib/types';

interface MessageListProps {
  messages: Message[];
  currentUser: User | null;
}

export default function MessageList({ messages, currentUser }: MessageListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <ScrollArea className="flex-1 p-4 bg-gradient-to-b from-background to-accent/5" ref={scrollRef}>
      <AnimatePresence>
        <div className="space-y-6">
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className={`flex items-start gap-3 ${
                message.authorId === currentUser?.id ? 'flex-row-reverse' : ''
              }`}
            >
              <Avatar className="ring-2 ring-primary/10 ring-offset-2 ring-offset-background transition-all duration-200 hover:ring-primary/30">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary-foreground flex items-center justify-center text-white uppercase font-medium">
                  {message.authorId === currentUser?.id ? 'Me' : 'U'}
                </div>
              </Avatar>

              <div
                className={`flex flex-col max-w-[70%] ${
                  message.authorId === currentUser?.id ? 'items-end' : ''
                }`}
              >
                <motion.div
                  initial={{ scale: 0.95 }}
                  animate={{ scale: 1 }}
                  className={`rounded-2xl p-4 shadow-sm transition-colors duration-200 ${
                    message.authorId === currentUser?.id
                      ? 'bg-gradient-to-br from-primary to-primary/90 text-white'
                      : 'bg-card hover:bg-card/95'
                  }`}
                >
                  <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>

                  {message.imageUrl && (
                    <motion.img
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      src={message.imageUrl}
                      alt="Shared image"
                      className="mt-3 max-w-sm rounded-lg shadow-lg hover:scale-[1.02] transition-transform duration-200"
                    />
                  )}

                  {message.fileUrl && (
                    <motion.a
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      href={message.fileUrl}
                      download={message.fileName}
                      className="mt-3 text-sm flex items-center gap-2 p-2 rounded-lg bg-background/10 hover:bg-background/20 transition-colors duration-200"
                    >
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        strokeWidth="2"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.112 2.13"
                        />
                      </svg>
                      {message.fileName}
                    </motion.a>
                  )}
                </motion.div>

                <span className="text-xs text-muted-foreground mt-1.5 px-2">
                  {new Date(message.createdAt).toLocaleTimeString()}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </AnimatePresence>
    </ScrollArea>
  );
}