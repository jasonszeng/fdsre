import { ScrollArea } from '@/components/ui/scroll-area';
import { motion } from 'framer-motion';
import type { User } from '@/lib/types';

interface UserListProps {
  users: User[];
  currentUser: User | null;
  onUserSelect: (user: User | null) => void;
}

export default function UserList({ users, currentUser, onUserSelect }: UserListProps) {
  return (
    <div className="h-full p-4 bg-gradient-to-b from-card to-background border-l">
      <h2 className="font-semibold mb-6 text-lg bg-gradient-to-r from-primary to-primary-foreground bg-clip-text text-transparent">
        Online Users
      </h2>
      <ScrollArea className="h-[calc(100vh-8rem)]">
        <div className="space-y-2">
          {users.map((user) => (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              whileHover={{ scale: 1.02 }}
              className={`
                flex items-center justify-between p-3 rounded-xl cursor-pointer
                transition-all duration-200
                ${user.id === currentUser?.id 
                  ? 'bg-primary/10 shadow-lg shadow-primary/5' 
                  : 'hover:bg-accent/50 hover:shadow-md'
                }
              `}
              onClick={() => {
                if (user.id !== currentUser?.id) {
                  onUserSelect(user);
                }
              }}
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary-foreground flex items-center justify-center text-white font-medium">
                    {user.username[0].toUpperCase()}
                  </div>
                  {user.status === 'online' && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-green-500 ring-2 ring-background"
                    />
                  )}
                </div>
                <div className="flex flex-col">
                  <span className="font-medium text-sm">{user.username}</span>
                  <span className="text-xs text-muted-foreground">
                    {user.status === 'online' ? 'Active now' : 'Offline'}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}