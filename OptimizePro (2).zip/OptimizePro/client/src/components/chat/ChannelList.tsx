import { ScrollArea } from '@/components/ui/scroll-area';
import { Hash } from 'lucide-react';
import { motion } from 'framer-motion';

interface ChannelListProps {
  currentChannel: string;
  onChannelSelect: (channel: string) => void;
}

const DEFAULT_CHANNELS = ['general', 'random', 'introductions'];

export default function ChannelList({
  currentChannel,
  onChannelSelect
}: ChannelListProps) {
  return (
    <div className="h-full p-4 bg-gradient-to-b from-card to-background border-r">
      <h2 className="font-semibold mb-6 text-lg bg-gradient-to-r from-primary to-primary-foreground bg-clip-text text-transparent">
        Channels
      </h2>
      <ScrollArea className="h-[calc(100vh-8rem)]">
        <div className="space-y-2">
          {DEFAULT_CHANNELS.map((channel, index) => (
            <motion.div
              key={channel}
              initial={{ opacity: 0, x: -20 }}
              animate={{ 
                opacity: 1, 
                x: 0,
                transition: { delay: index * 0.1 }
              }}
              whileHover={{ scale: 1.02 }}
              className={`
                flex items-center gap-3 p-3 rounded-xl cursor-pointer
                transition-all duration-200
                ${channel === currentChannel 
                  ? 'bg-primary/10 shadow-lg shadow-primary/5' 
                  : 'hover:bg-accent/50 hover:shadow-md'
                }
              `}
              onClick={() => onChannelSelect(channel)}
            >
              <div className={`
                w-8 h-8 rounded-lg flex items-center justify-center
                ${channel === currentChannel 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground'
                }
              `}>
                <Hash className="h-4 w-4" />
              </div>
              <span className="font-medium text-sm capitalize">{channel}</span>

              {channel === currentChannel && (
                <motion.div
                  layoutId="activeChannel"
                  className="absolute left-0 w-1 h-8 bg-primary rounded-r-full"
                />
              )}
            </motion.div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}