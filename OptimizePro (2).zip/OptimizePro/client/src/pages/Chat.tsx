import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useWebSocket } from '@/hooks/useWebSocket';
import MessageList from '@/components/chat/MessageList';
import MessageInput from '@/components/chat/MessageInput';
import UserList from '@/components/chat/UserList';
import ChannelList from '@/components/chat/ChannelList';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import type { User, Message } from '@/lib/types';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { ThemeToggle } from '@/components/ThemeToggle';

export default function Chat() {
  const [username, setUsername] = useState('');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showUsernameDialog, setShowUsernameDialog] = useState(true);
  const [currentChannel, setCurrentChannel] = useState('general');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const { toast } = useToast();

  // Queries
  const { data: users = [] } = useQuery<User[]>({ 
    queryKey: ['/api/users']
  });

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ['/api/messages', currentChannel],
    enabled: !!currentUser
  });

  // Mutations  
  const createUser = useMutation({
    mutationFn: async (username: string) => {
      const res = await apiRequest('POST', '/api/users', { username, status: 'online' });
      return res.json();
    },
    onSuccess: (user) => {
      setCurrentUser(user);
      setShowUsernameDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    }
  });

  // WebSocket handling
  const { sendMessage } = useWebSocket((msg) => {
    switch (msg.type) {
      case 'newMessage':
        if (msg.message) {
          queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
        }
        break;
      case 'userJoined':
        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
        toast({
          title: 'User Joined',
          description: `${msg.username} has joined the chat`
        });
        break;
    }
  });

  // Join chat when username is set
  useEffect(() => {
    if (currentUser) {
      sendMessage({
        type: 'join',
        username: currentUser.username
      });
    }
  }, [currentUser, sendMessage]);

  const handleJoin = async () => {
    if (!username.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a username"
      });
      return;
    }
    await createUser.mutateAsync(username);
  };

  return (
    <div className="h-screen flex">
      {/* Theme Toggle */}
      <div className="absolute top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      {/* Channel List */}
      <div className="w-64 bg-sidebar border-r">
        <ChannelList 
          currentChannel={currentChannel}
          onChannelSelect={setCurrentChannel}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        <MessageList 
          messages={messages}
          currentUser={currentUser}
        />
        <MessageInput
          onSendMessage={(content: string, imageUrl?: string, fileUrl?: string, fileName?: string) => {
            if (currentUser) {
              sendMessage({
                type: 'message',
                data: {
                  content,
                  authorId: currentUser.id,
                  channel: currentChannel,
                  isPrivate: !!selectedUser,
                  recipientId: selectedUser?.id,
                  imageUrl,
                  fileUrl,
                  fileName
                }
              });
            }
          }}
        />
      </div>

      {/* User List */}
      <div className="w-64 bg-sidebar border-l">
        <UserList
          users={users}
          currentUser={currentUser}
          onUserSelect={setSelectedUser}
        />
      </div>

      {/* Username Dialog */}
      <Dialog open={showUsernameDialog} onOpenChange={setShowUsernameDialog}>
        <DialogContent>
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">Join Chat</h2>
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              className="mb-4"
            />
            <Button 
              onClick={handleJoin}
              disabled={createUser.isPending}
            >
              Join
            </Button>
          </Card>
        </DialogContent>
      </Dialog>
    </div>
  );
}