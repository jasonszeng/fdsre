import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  status: text("status").notNull().default("online"),
  lastActive: timestamp("last_active").notNull().defaultNow()
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  authorId: serial("author_id").references(() => users.id),
  channel: text("channel").notNull(),
  isPrivate: boolean("is_private").default(false),
  recipientId: serial("recipient_id").references(() => users.id),
  imageUrl: text("image_url"),
  fileUrl: text("file_url"),
  fileName: text("file_name"),
  createdAt: timestamp("created_at").notNull().defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  status: true
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  authorId: true,
  channel: true,
  isPrivate: true,
  recipientId: true,
  imageUrl: true,
  fileUrl: true,
  fileName: true
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
