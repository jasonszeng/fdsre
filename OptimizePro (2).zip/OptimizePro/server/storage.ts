import { users, messages, type User, type InsertUser, type Message, type InsertMessage } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: number, status: string): Promise<User>;
  getAllUsers(): Promise<User[]>;
  removeUser(id: number): Promise<void>;

  // Message operations
  getMessages(channel: string): Promise<Message[]>;
  getPrivateMessages(user1Id: number, user2Id: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  deleteChannel(channel: string): Promise<void>;
  deletePrivateChat(user1Id: number, user2Id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private currentUserId: number = 1;
  private currentMessageId: number = 1;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      id,
      username: insertUser.username,
      status: insertUser.status || "online",
      lastActive: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStatus(id: number, status: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("User not found");

    const updated = {
      ...user,
      status,
      lastActive: new Date()
    };
    this.users.set(id, updated);
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async removeUser(id: number): Promise<void> {
    this.users.delete(id);
    // Remove all messages from/to this user
    for (const [msgId, msg] of Array.from(this.messages.entries())) {
      if (msg.authorId === id || msg.recipientId === id) {
        this.messages.delete(msgId);
      }
    }
  }

  async getMessages(channel: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.channel === channel && !m.isPrivate)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async getPrivateMessages(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.isPrivate && (
        (m.authorId === user1Id && m.recipientId === user2Id) ||
        (m.authorId === user2Id && m.recipientId === user1Id)
      ))
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      id,
      content: insertMessage.content,
      authorId: insertMessage.authorId!,
      channel: insertMessage.channel,
      isPrivate: insertMessage.isPrivate || false,
      recipientId: insertMessage.recipientId || 0,
      imageUrl: insertMessage.imageUrl || null,
      fileUrl: insertMessage.fileUrl || null,
      fileName: insertMessage.fileName || null,
      createdAt: new Date()
    };
    this.messages.set(id, message);
    return message;
  }

  async deleteChannel(channel: string): Promise<void> {
    for (const [msgId, msg] of Array.from(this.messages.entries())) {
      if (msg.channel === channel && !msg.isPrivate) {
        this.messages.delete(msgId);
      }
    }
  }

  async deletePrivateChat(user1Id: number, user2Id: number): Promise<void> {
    for (const [msgId, msg] of Array.from(this.messages.entries())) {
      if (msg.isPrivate && (
        (msg.authorId === user1Id && msg.recipientId === user2Id) ||
        (msg.authorId === user2Id && msg.recipientId === user1Id)
      )) {
        this.messages.delete(msgId);
      }
    }
  }
}

export const storage = new MemStorage();