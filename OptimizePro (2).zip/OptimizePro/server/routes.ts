import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import { log } from "./vite";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Create WebSocket server
  log("Initializing WebSocket server on path /ws", "websocket");
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // WebSocket connection handling
  wss.on('connection', (ws) => {
    log("New WebSocket connection established", "websocket");

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        log(`Received WebSocket message: ${JSON.stringify(message)}`, "websocket");

        switch (message.type) {
          case 'join':
            log(`User joined: ${message.username}`, "websocket");
            // Broadcast user joined
            wss.clients.forEach(client => {
              if (client !== ws && client.readyState === ws.OPEN) {
                client.send(JSON.stringify({
                  type: 'userJoined',
                  username: message.username
                }));
              }
            });
            break;

          case 'message':
            const savedMessage = await storage.createMessage(message.data);
            log(`Broadcasting message from ${savedMessage.userId}`, "websocket");
            // Broadcast message to all clients
            wss.clients.forEach(client => {
              if (client.readyState === ws.OPEN) {
                client.send(JSON.stringify({
                  type: 'newMessage',
                  message: savedMessage
                }));
              }
            });
            break;

          default:
            log(`Unknown message type: ${message.type}`, "websocket");
        }
      } catch (err) {
        log(`WebSocket message error: ${err}`, "websocket");
      }
    });

    ws.on('error', (error) => {
      log(`WebSocket error: ${error}`, "websocket");
    });

    ws.on('close', () => {
      log("WebSocket connection closed", "websocket");
    });
  });

  // REST API routes
  app.post('/api/users', async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const existing = await storage.getUserByUsername(data.username);
      if (existing) {
        return res.status(400).json({ message: 'Username already taken' });
      }
      const user = await storage.createUser(data);
      res.json(user);
    } catch (err) {
      res.status(400).json({ message: 'Invalid user data' });
    }
  });

  app.get('/api/users', async (_req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.post('/api/users/:id/status', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
      const user = await storage.updateUserStatus(parseInt(id), status);
      res.json(user);
    } catch (err) {
      res.status(404).json({ message: 'User not found' });
    }
  });

  app.delete('/api/users/:id', async (req, res) => {
    const { id } = req.params;
    await storage.removeUser(parseInt(id));
    res.status(204).send();
  });

  app.get('/api/messages/:channel', async (req, res) => {
    const { channel } = req.params;
    const messages = await storage.getMessages(channel);
    res.json(messages);
  });

  app.get('/api/messages/private/:user1Id/:user2Id', async (req, res) => {
    const { user1Id, user2Id } = req.params;
    const messages = await storage.getPrivateMessages(
      parseInt(user1Id),
      parseInt(user2Id)
    );
    res.json(messages);
  });

  app.post('/api/upload', upload.single('file'), async (req: Express.Request & { file?: Express.Multer.File }, res) => {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const fileId = uuidv4();
    const ext = path.extname(req.file.originalname);
    const fileName = `${fileId}${ext}`;

    // In memory storage - convert to base64
    const fileData = req.file.buffer.toString('base64');

    res.json({
      url: `data:${req.file.mimetype};base64,${fileData}`,
      fileName: req.file.originalname
    });
  });

  app.delete('/api/channels/:channel', async (req, res) => {
    const { channel } = req.params;
    await storage.deleteChannel(channel);
    res.status(204).send();
  });

  app.delete('/api/messages/private/:user1Id/:user2Id', async (req, res) => {
    const { user1Id, user2Id } = req.params;
    await storage.deletePrivateChat(parseInt(user1Id), parseInt(user2Id));
    res.status(204).send();
  });

  return httpServer;
}